#!/bin/bash
sleep 5 && ~/Desktop/Configs/ksetwallpaper.py ~/Desktop/Configs/thumb-1920-1002134.png


# ~/.config/thumb-1920-1002134.png
