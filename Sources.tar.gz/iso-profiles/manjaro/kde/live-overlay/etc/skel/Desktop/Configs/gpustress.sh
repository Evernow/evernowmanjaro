#!/bin/bash
gputest /test=fur /width=7680 /height=4230 &
unigine-valley &
glmark2
