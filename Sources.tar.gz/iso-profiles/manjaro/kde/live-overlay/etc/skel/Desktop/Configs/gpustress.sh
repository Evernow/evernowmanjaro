gputest /test=fur /width=7680 /height=4230 &
unigine-valley &
sleep 5 && wmctrl -r "GpuTest" -b toggle,shaded
