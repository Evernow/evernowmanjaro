# to force a certain look'n feel

#export SAL_USE_VCLPLUGIN=gen
#export SAL_USE_VCLPLUGIN=kde4
export SAL_USE_VCLPLUGIN=gtk
#export SAL_USE_VCLPLUGIN=gtk3 # currently broken and not available
