## Icons

Install the package `font-manager` and browse **icomoon**, **icons** and other icon fonts installed.