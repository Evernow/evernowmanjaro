[build-menu]
FT_00_LB=_Compile
FT_00_CM=g++ -Wall -c "%f"
FT_00_WD=
