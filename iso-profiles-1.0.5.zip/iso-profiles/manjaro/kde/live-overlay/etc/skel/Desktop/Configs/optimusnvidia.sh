#!/bin/bash
optimus-manager --switch nvidia
