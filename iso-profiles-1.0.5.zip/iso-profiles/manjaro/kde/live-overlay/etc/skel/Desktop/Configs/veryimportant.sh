~/.config/ksetwallpaper.py ~/.config/thumb-1920-1002134.png


# ~/.config/thumb-1920-1002134.png
