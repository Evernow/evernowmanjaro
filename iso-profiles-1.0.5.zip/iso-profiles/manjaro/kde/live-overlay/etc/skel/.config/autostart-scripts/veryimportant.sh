#!/bin/bash
python /home/manjaro/Desktop/Configs/PythonStartupCrap.py

# ~/.config/thumb-1920-1002134.png
